# SKIINBOX - Sitio listo para GitHub Pages

Instrucciones:
1. Descomprime este paquete.
2. Subir todos los archivos (index.html, style.css, script.js, assets/) a tu repositorio GitHub en la rama `main` (raíz).
3. En GitHub: Settings → Pages → Source: main / (root) → Save.
4. Tu sitio estará disponible en: https://<tu-usuario>.github.io/<repo>/

Si quieres que suba los archivos por ti a GitHub, dame tu usuario y crearé el repo público para que lo copies (no necesito tu contraseña).
